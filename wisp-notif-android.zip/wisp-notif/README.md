# Wisp Notif (Android)

Aplikasi kecil yang membaca notifikasi HP (mis. DANA Bisnis) lalu mengirimnya ke
`https://digital.wisp.uno/api/webhook/mutasi` supaya deposit PanelKu masuk otomatis.

Request yang dikirim (sesuai `index.js` PanelKu v17):

    POST /api/webhook/mutasi
    x-webhook-secret: <WEBHOOK_SECRET>
    {"mutationId":"<unik>","text":"<judul + isi notifikasi>","time":<epoch ms>}

## Build lewat GitHub
1. Buat repo baru di GitHub, upload **isi** folder ini (termasuk folder `.github`).
2. Buka tab **Actions** -> workflow **Build APK** jalan otomatis (atau Run workflow).
3. Selesai (±3-5 menit) -> buka run-nya -> **Artifacts** -> unduh `WispNotif-apk` -> ekstrak -> install `app-release.apk`.

## Pasang di HP admin
1. Buka app -> tombol 1: aktifkan **Akses notifikasi** untuk Wisp Notif.
2. Tombol 2: bebaskan dari hemat baterai. Di Xiaomi/Oppo/Vivo/Realme/Samsung juga nyalakan **Autostart** dan kunci app di Recent Apps.
3. Isi **Secret** = `WEBHOOK_SECRET` di `.env` PanelKu (di server harus terisi, dan restart panel setelah mengisi).
4. Simpan -> **Kirim tes koneksi** -> log harus menampilkan `TES OK`.

## Catatan
- Setelah izin aktif, Android yang menjalankan layanan ini, jadi tetap menerima notifikasi walau aplikasi ditutup. Syarat: notifikasi aplikasi DANA tidak dimatikan, data/internet hidup.
- Kalau internet mati, kiriman masuk antrian dan dicoba lagi otomatis (maks 2 jam).
- "Hanya kirim uang masuk" memakai kata kunci yang sama dengan server (`masuk/diterima/...` + `Rp`). Matikan kalau notifikasi kamu formatnya lain.
- Log menampilkan nama paket tiap notifikasi, jadi bisa dipakai untuk mengisi Filter paket.
- URL harus `https`.
- Keystore (`app/wisp.keystore`) ikut repo supaya update APK bisa menimpa versi lama. Repo sebaiknya **private**.
