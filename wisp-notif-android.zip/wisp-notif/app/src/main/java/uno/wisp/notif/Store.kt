package uno.wisp.notif

import android.content.Context
import android.content.SharedPreferences
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Store {
    const val DEFAULT_URL = "https://digital.wisp.uno/api/webhook/mutasi"
    private const val MAX_LOG = 40

    private fun p(ctx: Context): SharedPreferences =
        ctx.applicationContext.getSharedPreferences("wisp", Context.MODE_PRIVATE)

    fun url(ctx: Context): String = p(ctx).getString("url", DEFAULT_URL) ?: DEFAULT_URL
    fun secret(ctx: Context): String = p(ctx).getString("secret", "") ?: ""
    fun filter(ctx: Context): String = p(ctx).getString("filter", "") ?: ""
    fun onlyIncoming(ctx: Context): Boolean = p(ctx).getBoolean("onlyIncoming", true)
    fun enabled(ctx: Context): Boolean = p(ctx).getBoolean("enabled", true)

    fun save(ctx: Context, url: String, secret: String, filter: String, onlyIncoming: Boolean, enabled: Boolean) {
        p(ctx).edit()
            .putString("url", url.trim())
            .putString("secret", secret.trim())
            .putString("filter", filter.trim())
            .putBoolean("onlyIncoming", onlyIncoming)
            .putBoolean("enabled", enabled)
            .apply()
    }

    @Synchronized
    fun log(ctx: Context, line: String) {
        val t = SimpleDateFormat("dd/MM HH:mm:ss", Locale.US).format(Date())
        val old = p(ctx).getString("log", "") ?: ""
        val lines = (listOf("$t  $line") + old.split("\n").filter { it.isNotBlank() }).take(MAX_LOG)
        p(ctx).edit().putString("log", lines.joinToString("\n")).apply()
    }

    fun logText(ctx: Context): String = p(ctx).getString("log", "") ?: ""
    fun clearLog(ctx: Context) { p(ctx).edit().putString("log", "").apply() }
}
