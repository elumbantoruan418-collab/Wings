package uno.wisp.notif

import android.app.Notification
import android.content.ComponentName
import android.os.Build
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.security.MessageDigest
import java.util.concurrent.Executors

/**
 * Dijalankan sistem Android selama izin "Akses notifikasi" aktif,
 * jadi tetap menerima notifikasi walau aplikasi sudah ditutup/di-swipe.
 */
class NotifService : NotificationListenerService() {

    private val io = Executors.newFixedThreadPool(2)

    override fun onListenerConnected() {
        Store.log(this, "Listener tersambung")
    }

    override fun onListenerDisconnected() {
        Store.log(this, "Listener terputus, mencoba menyambung lagi")
        if (Build.VERSION.SDK_INT >= 24) {
            try { requestRebind(ComponentName(this, NotifService::class.java)) } catch (_: Exception) {}
        }
    }

    override fun onDestroy() {
        io.shutdown()
        super.onDestroy()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            handle(sbn)
        } catch (e: Exception) {
            Store.log(this, "Error: ${e.javaClass.simpleName} ${e.message ?: ""}")
        }
    }

    private fun handle(sbn: StatusBarNotification) {
        if (!Store.enabled(this)) return
        val pkg = sbn.packageName ?: return
        if (pkg == packageName) return

        val n = sbn.notification ?: return
        val ex = n.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim() ?: ""
        val big = ex.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()?.trim() ?: ""
        val txt = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim() ?: ""
        val body = if (big.isNotEmpty()) big else txt
        val full = listOf(title, body).filter { it.isNotEmpty() }.joinToString("\n").take(500)
        if (full.isEmpty()) return

        val allow = Store.filter(this).split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }
        if (allow.isNotEmpty() && pkg.lowercase() !in allow) {
            Store.log(this, "Diabaikan (paket $pkg)")
            return
        }

        if (Store.onlyIncoming(this) && !looksIncoming(full)) {
            Store.log(this, "Diabaikan (bukan uang masuk) [$pkg] ${full.take(40).replace('\n', ' ')}")
            return
        }

        val whenMs = if (n.`when` > 0) n.`when` else sbn.postTime
        val id = sha1("$pkg|$whenMs|$full").take(24)
        val time = sbn.postTime
        Store.log(this, "Notif [$pkg] ${full.take(50).replace('\n', ' ')}")

        io.execute {
            val r = Sender.send(applicationContext, id, full, time)
            Store.log(applicationContext, (if (r.ok) "TERKIRIM " else "GAGAL ") + r.msg)
            if (!r.ok && r.retry) SendWorker.enqueue(applicationContext, id, full, time)
        }
    }

    // Aturan sama dengan parseIncoming di server PanelKu
    private fun looksIncoming(t: String): Boolean {
        if (!Regex("(masuk|diterima|menerima|terima|received|kredit)", RegexOption.IGNORE_CASE).containsMatchIn(t)) return false
        if (Regex("(keluar|dikirim|kirim ke|transfer ke|pembayaran ke|ditarik|penarikan|gagal|dibatalkan|refund|dikembalikan)", RegexOption.IGNORE_CASE).containsMatchIn(t)) return false
        return Regex("rp\\.?\\s*[0-9]", RegexOption.IGNORE_CASE).containsMatchIn(t)
    }

    private fun sha1(s: String): String =
        MessageDigest.getInstance("SHA-1").digest(s.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
}
