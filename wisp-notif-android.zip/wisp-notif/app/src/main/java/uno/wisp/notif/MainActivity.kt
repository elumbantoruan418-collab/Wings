package uno.wisp.notif

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var etUrl: EditText
    private lateinit var etSecret: EditText
    private lateinit var etFilter: EditText
    private lateinit var cbIncoming: CheckBox
    private lateinit var cbEnabled: CheckBox
    private lateinit var logView: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String) = TextView(this).apply {
        text = t; textSize = 13f; setTextColor(0xFF475569.toInt()); setPadding(0, dp(14), 0, dp(4))
    }

    private fun field(hint: String) = EditText(this).apply {
        this.hint = hint; textSize = 14f; setSingleLine(true)
    }

    private fun btn(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(28), dp(18), dp(28))
        }

        root.addView(TextView(this).apply {
            text = "Wisp Notif"; textSize = 24f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF0F172A.toInt())
        })
        root.addView(TextView(this).apply {
            text = "Meneruskan notifikasi uang masuk ke webhook mutasi Digital Wisp."
            textSize = 13f; setTextColor(0xFF64748B.toInt())
        })

        status = TextView(this).apply {
            textSize = 14f; setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(0xFFEEF2FB.toInt())
        }
        root.addView(label("Status"))
        root.addView(status)

        root.addView(btn("1. Aktifkan akses notifikasi") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        root.addView(btn("2. Izinkan jalan di latar belakang (hemat baterai: bebas)") {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:$packageName")))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        })

        etUrl = field("URL webhook")
        etUrl.inputType = InputType.TYPE_TEXT_VARIATION_URI
        root.addView(label("URL webhook"))
        root.addView(etUrl)

        etSecret = field("Sama dengan WEBHOOK_SECRET di .env PanelKu")
        etSecret.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        root.addView(label("Secret (WEBHOOK_SECRET)"))
        root.addView(etSecret)

        etFilter = field("kosong = semua aplikasi, contoh: id.dana")
        root.addView(label("Filter nama paket aplikasi (pisah koma, opsional)"))
        root.addView(etFilter)

        cbIncoming = CheckBox(this).apply { text = "Hanya kirim notifikasi uang masuk (disarankan)" }
        cbEnabled = CheckBox(this).apply { text = "Pengiriman aktif" }
        root.addView(cbIncoming)
        root.addView(cbEnabled)

        root.addView(btn("Simpan") { save(); toast("Tersimpan") })
        root.addView(btn("Kirim tes koneksi") { testSend() })

        root.addView(label("Log terakhir"))
        logView = TextView(this).apply {
            textSize = 11f; typeface = Typeface.MONOSPACE; setTextColor(0xFF0F172A.toInt())
            setTextIsSelectable(true)
        }
        root.addView(logView)
        root.addView(btn("Muat ulang log") { refresh() })
        root.addView(btn("Hapus log") { Store.clearLog(this); refresh() })

        setContentView(ScrollView(this).apply { addView(root) })
        load()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun load() {
        etUrl.setText(Store.url(this))
        etSecret.setText(Store.secret(this))
        etFilter.setText(Store.filter(this))
        cbIncoming.isChecked = Store.onlyIncoming(this)
        cbEnabled.isChecked = Store.enabled(this)
    }

    private fun save() {
        Store.save(this, etUrl.text.toString(), etSecret.text.toString(), etFilter.text.toString(),
            cbIncoming.isChecked, cbEnabled.isChecked)
    }

    private fun listenerOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return s.split(":").any { it.startsWith("$packageName/") }
    }

    private fun batteryOk(): Boolean {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(packageName)
    }

    private fun refresh() {
        val l = listenerOn()
        val b = batteryOk()
        status.text = (if (l) "✓ Akses notifikasi: AKTIF" else "✗ Akses notifikasi: MATI (tekan tombol 1)") + "\n" +
            (if (b) "✓ Latar belakang: bebas hemat baterai" else "! Latar belakang: belum dibebaskan (tekan tombol 2)") + "\n" +
            (if (Store.secret(this).isBlank()) "✗ Secret belum diisi" else "✓ Secret terisi")
        logView.text = Store.logText(this).ifBlank { "(belum ada log)" }
    }

    private fun testSend() {
        save()
        val ctx = applicationContext
        Executors.newSingleThreadExecutor().execute {
            val r = Sender.send(ctx, "tes-" + System.currentTimeMillis(), "Tes koneksi Wisp Notif", System.currentTimeMillis())
            Store.log(ctx, (if (r.ok) "TES OK " else "TES GAGAL ") + r.msg)
            runOnUiThread {
                refresh()
                toast(if (r.ok) "Koneksi OK" else "Gagal: ${r.msg}")
            }
        }
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()
}
