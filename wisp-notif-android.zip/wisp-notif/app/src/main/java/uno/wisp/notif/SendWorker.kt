package uno.wisp.notif

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/** Antrian kirim ulang: dipakai kalau kirim langsung gagal (mis. internet mati). */
class SendWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {

    override fun doWork(): Result {
        val id = inputData.getString("id") ?: return Result.failure()
        val text = inputData.getString("text") ?: return Result.failure()
        val time = inputData.getLong("time", System.currentTimeMillis())
        // Notifikasi yang terlalu lama tertahan (>2 jam) tidak dikirim lagi
        if (System.currentTimeMillis() - time > 2 * 3600_000L) {
            Store.log(applicationContext, "Dibuang (terlalu lama): ${text.take(40).replace('\n', ' ')}")
            return Result.failure()
        }
        val r = Sender.send(applicationContext, id, text, time)
        Store.log(applicationContext, (if (r.ok) "TERKIRIM (ulang) " else "GAGAL (ulang) ") + r.msg)
        return when {
            r.ok -> Result.success()
            r.retry -> Result.retry()
            else -> Result.failure()
        }
    }

    companion object {
        fun enqueue(ctx: Context, id: String, text: String, time: Long) {
            val data = Data.Builder().putString("id", id).putString("text", text).putLong("time", time).build()
            val req = OneTimeWorkRequestBuilder<SendWorker>()
                .setInputData(data)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 15, TimeUnit.SECONDS)
                .build()
            WorkManager.getInstance(ctx.applicationContext)
                .enqueueUniqueWork("send-$id", ExistingWorkPolicy.KEEP, req)
        }
    }
}
