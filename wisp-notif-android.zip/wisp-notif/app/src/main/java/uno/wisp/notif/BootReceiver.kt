package uno.wisp.notif

import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.service.notification.NotificationListenerService

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (Build.VERSION.SDK_INT >= 24) {
            try {
                NotificationListenerService.requestRebind(ComponentName(context, NotifService::class.java))
            } catch (_: Exception) {}
        }
        Store.log(context, "HP menyala / aplikasi diperbarui")
    }
}
