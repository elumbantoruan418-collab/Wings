package uno.wisp.notif

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Sender {
    class Res(val ok: Boolean, val retry: Boolean, val msg: String)

    fun send(ctx: Context, id: String, text: String, time: Long): Res {
        val url = Store.url(ctx)
        val secret = Store.secret(ctx)
        if (url.isBlank() || secret.isBlank()) return Res(false, false, "URL atau secret masih kosong")
        var c: HttpURLConnection? = null
        return try {
            c = URL(url).openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 20000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.setRequestProperty("x-webhook-secret", secret)
            val body = JSONObject()
                .put("mutationId", id)
                .put("text", text)
                .put("time", time)
                .toString()
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val resp = stream?.bufferedReader()?.use { it.readText() }?.take(160) ?: ""
            when {
                code in 200..299 -> Res(true, false, "HTTP $code $resp")
                code == 429 || code >= 500 -> Res(false, true, "HTTP $code (akan dicoba lagi) $resp")
                else -> Res(false, false, "HTTP $code $resp")
            }
        } catch (e: Exception) {
            Res(false, true, "Gagal koneksi: ${e.javaClass.simpleName} ${e.message ?: ""}".take(160))
        } finally {
            c?.disconnect()
        }
    }
}
